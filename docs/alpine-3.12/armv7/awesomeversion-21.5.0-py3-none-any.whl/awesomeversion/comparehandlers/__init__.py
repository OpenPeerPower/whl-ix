"""Initialize the comparehandlers for AwesomeVersion."""
